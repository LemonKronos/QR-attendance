import streamlit.components.v1 as components

# Makes every input box white with a dark-blue border on every device,
# even when the phone or browser is in dark mode.
FORCE_LIGHT_INPUTS_SCRIPT = """
<script>
    (function() {
        const parentDocument = window.parent.document;
        let colorSchemeMeta = parentDocument.querySelector('meta[name="color-scheme"]');
        if (!colorSchemeMeta) {
            colorSchemeMeta = parentDocument.createElement('meta');
            colorSchemeMeta.name = 'color-scheme';
            parentDocument.head.appendChild(colorSchemeMeta);
        }
        colorSchemeMeta.content = 'only light';

        function enforceLightInputs() {
            const inputWrappers = parentDocument.querySelectorAll('[data-baseweb="input"]');
            inputWrappers.forEach(inputWrapper => {
                inputWrapper.style.setProperty('background-color', '#FFFFFF', 'important');
                inputWrapper.style.setProperty('background', '#FFFFFF', 'important');
                inputWrapper.style.setProperty('border', '2px solid #030391', 'important');
                inputWrapper.style.setProperty('border-radius', '14px', 'important');
                inputWrapper.style.setProperty('box-shadow', 'none', 'important');
            });
            const innerDivs = parentDocument.querySelectorAll('[data-baseweb="base-input"], [data-baseweb="input"] > div');
            innerDivs.forEach(innerDiv => {
                innerDiv.style.setProperty('background-color', '#FFFFFF', 'important');
                innerDiv.style.setProperty('background', '#FFFFFF', 'important');
                innerDiv.style.setProperty('border', 'none', 'important');
            });
            const inputElements = parentDocument.querySelectorAll('input');
            inputElements.forEach(inputElement => {
                inputElement.style.setProperty('background-color', '#FFFFFF', 'important');
                inputElement.style.setProperty('background', '#FFFFFF', 'important');
                inputElement.style.setProperty('color', '#000000', 'important');
                inputElement.style.setProperty('-webkit-text-fill-color', '#000000', 'important');
            });
        }
        enforceLightInputs();
        const mutationObserver = new MutationObserver(enforceLightInputs);
        mutationObserver.observe(parentDocument.body, { childList: true, subtree: true });
    })();
</script>
"""


def force_light_inputs() -> None:
    components.html(FORCE_LIGHT_INPUTS_SCRIPT, height=0)
