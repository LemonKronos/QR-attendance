import streamlit as st

from utils import security

# Streamlit builds one URL per page, taken from `url_path`.
#   /                      neutral landing page (reveals nothing)
#   /teacher               password-protected teacher portal
#   /checkin-<random>      student page; the random part comes from secret.key,
#                          so it cannot be guessed and only appears inside the QR code
# position="hidden" removes the sidebar menu, so no page links to another one.
pages = [
    st.Page("views/landing.py", title="Điểm danh lớp học", default=True),
    st.Page("views/teacher.py", title="Cổng giảng viên", url_path="teacher"),
    st.Page(
        "views/student.py",
        title="Điểm danh sinh viên",
        url_path=security.get_student_page_path(),
    ),
]

navigation = st.navigation(pages, position="hidden")
navigation.run()
